- Credits to: AdityaGans2542 & Oshekher
- Fixed by: Hieupc

> WARNNING: 
THIS IS ONLY FOR EDUCATIONAL PURPOSES
DON'T USE FOR MINING OR ILLEGAL USE

With this method, you can create as many RDPs as you want through Github.

<img src="https://i.imgur.com/djAquTl.png" align="center">

> Press the Fork button to create a Free RDP 6 hours with 2CPU 7GB RAM 256 SSD (For Smartphones, Please Use Desktop Mode).

> Signup an account at https://ngrok.com to get NGROK_AUTH_TOKEN

> Inside this Repo Go to Settings> Secrets> New repository secret

> Fill in the Name: Enter NGROK_AUTH_TOKEN

> Fill in Value: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste in the value

> Press Add secret 

> Go to Action >  7onez > Run workflow > Run workflow > Wait for 3s then go to the next step.

> Refresh Web and go to  7onez > build > Wait for 30s to 60s then go to the next step.

> Press Down facing arrow button "Thông tin RPD miễn phí của bạn CPU 2 Core - 7GB Ram - 256 SSD." To Get IP, User, Password.
 
> You can change password of the VPS if you want as normally

> Use at your own risk.

(Every 6 hours, you just delete the workflow run and then create again - by repeating this step "Go to Action >  7onez > Run workflow > Run workflow" to create another free RPD)
